# Purpose: Clip each watershed in directory from the base grid nwalt

# Import the arcpy
import arcpy
from arcpy.sa import *
from arcpy import env
arcpy.env.overwriteOutput = True


# Input workspace
WS = "F:\\natsyn\\DelawareRiverBasin\\DRB2021\\GIS\\RoadSaltDRB\\"
# Input NWALT raster is here.  Change year
RS = "F:\\HoldData4Edrive\\nwalt\\"
# clip basin polygons are here
BS = "F:\\natsyn\\DelawareRiverBasin\\DRB2021\\GIS\\BaseCovers\\"
# put the final rasters here.  Change year
FS = "F:\\natsyn\\DelawareRiverBasin\\DRB2021\\GIS\\RoadSaltDRB\\"
# Input environment 
arcpy.env.workspace = WS



#Make grid for each 

a=[#'1992',\
#'1993',\
'1994',\
'1995',\
'1996',\
'1997',\
'1998',\
'1999',\
'2000',\
'2001',\
'2002',\
'2003',\
'2004',\
'2005',\
'2006',\
'2007',\
'2008',\
'2009',\
'2010',\
'2011',\
'2012',\
'2013',\
'2014',\
'2015']


for x in a :

    print 'Starting watershed ' + repr(x)
    
    

    # input variables
    in_raster = WS + "DRB" + x + ".tif"
    out_raster = FS + "DRBint" + x + ".tif"

    out_Int = Int(in_raster +.5)
    outInt.save(FS + "DRBint" + x + ".tif")
    
    #

print "YOU ARE DONE"
