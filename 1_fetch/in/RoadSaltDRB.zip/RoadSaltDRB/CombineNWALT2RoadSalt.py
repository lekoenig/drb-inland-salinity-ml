# Purpose: Clip each watershed in directory from the base grid nwalt

# Import the arcpy
import arcpy
from arcpy.sa import *
from arcpy import env
arcpy.env.overwriteOutput = True


# Input workspace
WS = "F:\\natsyn\\DelawareRiverBasin\\DRB2021\\GIS\\RoadSaltDRB\\"
# Input NWALT raster is here.  Change year
RS = "F:\\natsyn\\DelawareRiverBasin\\DRB2021\\GIS\\BaseCovers\\"
# clip basin polygons are here
BS = "F:\\natsyn\\DelawareRiverBasin\\DRB2021\\GIS\\BaseCovers\\"
# put the final rasters here.  Change year
FS = "F:\\natsyn\\DelawareRiverBasin\\DRB2021\\GIS\\RoadSaltDRB\\"
# Input environment 
arcpy.env.workspace = WS
arcpy.CheckOutExtension("Spatial")



#Make grid for each 

#a=[#'1992',\
#'1993',\
#'1994',\
#'1995',\
#'1996',\
#'1997']

#for x in a:

 #   print 'Starting watershed ' + repr(x)

  #  in_raster01 = WS + "DRB" + x + "int.tif"
  #  in_rasterLU92 = RS + "DRB_NWALT1K_1992.tif"
    # out_raster01 = FS + "DRB" + x + "LU92.tif"
    

    #outCombine = Combine([in_rasterLU92, in_raster01])
    #outCombine.save("F:\\natsyn\\DelawareRiverBasin\\DRB2021\\GIS\\RoadSaltDRB\\outcombine.tif")
    #arcpy.Rename_management("outcombine.tif", out_raster01)
    #print 'End Lu92'


b=['1998',\
'1999',\
'2000',\
'2001',\
'2002',\
'2003',\
'2004',\
'2005',\
'2006']

for y in b:
    
    print 'Starting watershed ' + repr(y)

    in_raster02 = WS + "DRB" + y + "int.tif"
    in_rasterLU02 = RS + "DRB_NWALT1K_2002.tif"
    out_raster02 = FS + "DRB" + y + "LU02.tif"
    

    outCombine = Combine([in_rasterLU02, in_raster02])
    outCombine.save("F:\\natsyn\\DelawareRiverBasin\\DRB2021\\GIS\\RoadSaltDRB\\outcombine.tif")
    arcpy.Rename_management("outcombine.tif", out_raster02)
    print 'End Lu02'   

c=['2007',\
'2008',\
'2009',\
'2010',\
'2011',\
'2012',\
'2013',\
'2014',\
'2015']

for z in c:
    
    print 'Starting watershed ' + repr(z)

    in_raster03 = WS + "DRB" + z + "int.tif"
    in_rasterLU12 = RS + "DRB_NWALT1K_2012.tif"
    out_raster03 = FS + "DRB" + z + "LU12.tif"
    

    outCombine = Combine([in_rasterLU12, in_raster03])
    outCombine.save("F:\\natsyn\\DelawareRiverBasin\\DRB2021\\GIS\\RoadSaltDRB\\outcombine.tif")
    arcpy.Rename_management("outcombine.tif", out_raster03)
    
    print 'End Lu12'
 
arcpy.CheckInExtension("Spatial")
print "YOU ARE DONE"
